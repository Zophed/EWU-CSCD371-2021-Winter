﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericStuff
{
    public interface IDescription
    {
        string Description { get; }
    }
}
